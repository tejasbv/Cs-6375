To run the program with example one please use the command below 

pythonpython3 id3variant.py dataset-1.txt partition-1.txt partition-2.txt

To run the program with example two please use the command below

pythonpython3 id3variant.py dataset-2.txt partition-1-d2.txt partition-2.txt
